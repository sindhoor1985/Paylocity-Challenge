﻿using System;
using System.Collections.Generic;
using PMS.Model;
using System.Data;
using System.Data.SqlClient;

namespace PMS.Data
{
    public static class PMSData
    {
        public static List<Employee> GetAllEmployees()
        {
            DataTable dt = SQLHelper.ExecuteDataTable(@"    SELECT E.[EmpId],E.[FirstName],E.[LastName],E.[DOB],E.[SSN],E.[Gender],E.[Salary],E.[Email]" +
                "                                           FROM [PMS].[dbo].[Employees]");

            List<Employee> ToReturn = new List<Employee>();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ToReturn.Add(new Employee() { 
                        EmpId = Convert.ToInt32(dr["EmpId"]),
                        FirstName = Convert.ToString(dr["FirstName"]),
                        LastName = Convert.ToString(dr["LastName"]),
                        DOB = Convert.ToDateTime(dr["DOB"]).ToString("d/M/yyyy"),
                        SSN = Convert.ToInt32(dr["SSN"]),
                        Gender = Convert.ToString(dr["Gender"]),
                        Salary = Convert.ToInt32(dr["Salary"]),
                        Email = Convert.ToString(dr["Email"])
                    });
                }
            }

            return ToReturn;
        }

        public static List<Dashboard> GenerateHomeDashboard()
        {
            DataTable dt = SQLHelper.ExecuteDataTable(@"[dbo].[usp_GeneratePMSDashboard]");

            List<Dashboard> ToReturn = new List<Dashboard>();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ToReturn.Add(new Dashboard()
                    {
                        EmpId = Convert.ToInt32(dr["EmpId"]),
                        FirstName = Convert.ToString(dr["FirstName"]),
                        LastName = Convert.ToString(dr["LastName"]),
                        DOB = Convert.ToDateTime(dr["DOB"]).ToString("d/M/yyyy"),
                        SSN = Convert.ToInt32(dr["SSN"]),
                        Gender = Convert.ToString(dr["Gender"]),
                        Salary = Convert.ToInt32(dr["Salary"]),
                        Email = Convert.ToString(dr["Email"]),
                        EmployeeBenefitsCost = Convert.ToInt32(dr["EmployeeBenefitsCost"]),
                        DependentBenefitsCost = Convert.ToInt32(dr["DependentBenefitsCost"])
                    });
                }
            }

            return ToReturn;
        }

        public static bool AddNewEmployee(Employee employee)
        {

            List<SqlParameter> parameters = new List<SqlParameter>();

            parameters.Add(new SqlParameter() { 
                ParameterName = "@FirstName",
                Value = employee.FirstName
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@LastName",
                Value = employee.LastName
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@DOB",
                Value = employee.DOB
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@Gender",
                Value = employee.Gender
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@SSN",
                Value = employee.SSN
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@Salary",
                Value = employee.Salary
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@Email",
                Value = employee.Email
            });

            int numberOfRowsAffected = SQLHelper.ExecuteStoredProcedure("[dbo].[usp_AddNewEmployee]", parameters.ToArray());

            return (numberOfRowsAffected == 1);
        }

        public static List<DependentType> GetAllDependentTypes()
        {
            DataTable dt = SQLHelper.ExecuteDataTable("SELECT [Id],[Type] FROM [PMS].[dbo].[DependentTypes] ORDER BY [Id]");

            List<DependentType> ToReturn = new List<DependentType>();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ToReturn.Add(new DependentType()
                    {
                        DeptTypeId = Convert.ToInt32(dr["Id"]),
                        DeptTypeName = Convert.ToString(dr["Type"]),
                    });
                }
            }

            return ToReturn;
        }

        public static bool AddNewDependent(Dependent dependent)
        {

            List<SqlParameter> parameters = new List<SqlParameter>();

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@EmpId",
                Value = dependent.EmpId
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@DeptTypeId",
                Value = dependent.DeptTypeId
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@FirstName",
                Value = dependent.FirstName
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@LastName",
                Value = dependent.LastName
            });

            parameters.Add(new SqlParameter()
            {
                ParameterName = "@DOB",
                Value = dependent.DOB
            });


            parameters.Add(new SqlParameter()
            {
                ParameterName = "@SSN",
                Value = dependent.SSN
            });

            int numberOfRowsAffected = SQLHelper.ExecuteStoredProcedure("[dbo].[usp_AddNewDependent]", parameters.ToArray());

            return (numberOfRowsAffected == 1);
        }

        public static List<Tuple<int, string>> GetAllEmployeeNames()
        {
            DataTable dt = SQLHelper.ExecuteDataTable("[dbo].[usp_GetAllEmployees]");

            List<Tuple<int, string>> ToReturn = new List<Tuple<int, string>>();

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    ToReturn.Add(Tuple.Create(Convert.ToInt32(dr["EmpId"]), Convert.ToString(dr["Name"])));
                }
            }

            return ToReturn;
        }

    }
}
