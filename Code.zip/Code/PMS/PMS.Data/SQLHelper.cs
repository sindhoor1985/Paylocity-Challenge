﻿using System;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace PMS.Data
{
    public class SQLHelper
    {
        /// <summary>
        ///  Get the connection string from the configuration file
        /// </summary>
        /// <returns>Connection string</returns>
        public static string GetSqlConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["DatabaseConnectionString"].ConnectionString;
        }

        /// <summary>
        ///  Encapsulate an executed sql to return the number of affected rows
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>Number of rows affected</returns>
        public static int ExecuteStoredProcedure(string procedureName, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(GetSqlConnectionString()))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();  //Open the database
                    cmd.CommandText = procedureName;  //Assign a value to CommandText
                    cmd.Parameters.AddRange(parameters);  // Assign values ​​to the database usage parameters
                    cmd.CommandType = CommandType.StoredProcedure;
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        ///  Encapsulate an executed sql to return the number of affected rows
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>Number of rows affected</returns>
        public static int ExecuteNonQuery(string sqlText, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(GetSqlConnectionString()))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();  //Open the database
                    cmd.CommandText = sqlText;  //Assign a value to CommandText
                    cmd.Parameters.AddRange(parameters);  // Assign values ​​to the database usage parameters
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        ///  Execute sql and return the value of the first row and first column in the query result
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>The value of the first row and first column in the query result</returns>
        public static object ExecuteScalar(string sqlText, params SqlParameter[] parameters)
        {
            using (SqlConnection conn = new SqlConnection(GetSqlConnectionString()))
            {
                using (SqlCommand cmd = conn.CreateCommand())
                {
                    conn.Open();
                    cmd.CommandText = sqlText;
                    cmd.Parameters.AddRange(parameters);
                    return cmd.ExecuteScalar();
                }
            }
        }

        /// <summary>
        ///  Executing sql returns a DataTable
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>Return a DataTable</returns>
        public static DataTable ExecuteDataTable(string sqlText, params SqlParameter[] parameters)
        {
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlText, GetSqlConnectionString()))
            {
                DataTable dt = new DataTable();
                adapter.SelectCommand.Parameters.AddRange(parameters);
                adapter.Fill(dt);
                return dt;
            }
        }

        /// <summary>
        ///  Executing sql returns a DataSet
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>Return a DataSet</returns>
        public static DataSet ExecuteDataSet(string sqlText, params SqlParameter[] parameters)
        {
            using (SqlDataAdapter adapter = new SqlDataAdapter(sqlText, GetSqlConnectionString()))
            {
                DataSet ds = new DataSet();
                adapter.SelectCommand.Parameters.AddRange(parameters);
                adapter.Fill(ds);
                return ds;
            }
        }

        /// <summary>
        ///  Execute sql script
        /// </summary>
        /// <param name="sqlText">Sql script executed</param>
        /// <param name="parameters">Parameter set</param>
        /// <returns>Return a SqlDataReader</returns>
        public static SqlDataReader ExecuteReader(string sqlText, params SqlParameter[] parameters)
        {
            //SqlDataReader requires that when it reads data, it monopolizes its SqlConnection object, and SqlConnection must be in the Open state
            SqlConnection conn = new SqlConnection(GetSqlConnectionString());//Do not release the connection, because the connection is still open later
            SqlCommand cmd = conn.CreateCommand();
            conn.Open();
            cmd.CommandText = sqlText;
            cmd.Parameters.AddRange(parameters);
            //CommandBehavior.CloseConnection When the SqlDataReader is released, the SqlConnection object is also released by the way
            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }

    }
}
