﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

namespace PMS.Web.Helper
{
    public static class ConfigHelper
    {
        public static string ApiUrl { get; set; }

        static ConfigHelper()
        {
            ApiUrl = ConfigurationManager.AppSettings["PMS.Web.Api.Url"];
        }
    }
}