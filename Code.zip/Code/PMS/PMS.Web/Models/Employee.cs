﻿using System;

namespace PMS.Models
{
    public class Employee
    {
        //public int EmpId { get; set; }
        //public string Prefix { get; set; }
        public string FirstName { get; set; }
        //public string MiddleName { get; set; }
        public string LastName { get; set; }
        //public string Suffix { get; set; }
        public string DOB { get; set; }
        //public string StateId { get; set; }
        public string Gender { get; set; }
        //public string PassportNumber { get; set; }
        public int SSN { get; set; }
        public int Salary { get; set; }
        //public string Position { get; set; }
        //public string BusinessTitle { get; set; }
        //public string JobProfile { get; set; }
        //public string Location { get; set; }
        //public string HireDate { get; set; }
        //public string PhoneNumber { get; set; }
        public string Email { get; set; }
        //public string TeammateType { get; set; }

    }

    public class Dashboard : Employee
    {

        public int EmployeeBenefitsCost { get; set; }
        public int DependentBenefitsCost { get; set; }

    }
}