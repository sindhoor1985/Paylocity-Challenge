﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using PMS.Models;
using PMS.Web.Helper;
using Newtonsoft.Json;

namespace PMS.Web
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            WebClient client = new WebClient();

            List<Dashboard> lstDashboard = JsonConvert.DeserializeObject<List<Dashboard>>(client.DownloadString(ConfigHelper.ApiUrl + "Employee"));

            grdEmployeesGridView.DataSource = lstDashboard;
            grdEmployeesGridView.DataBind();
        }
    }

}