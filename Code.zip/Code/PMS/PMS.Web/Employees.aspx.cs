﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using PMS.Models;
using PMS.Web.Helper;
using Newtonsoft.Json;

namespace PMS.Web
{
    public partial class About : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string apiUrl = ConfigHelper.ApiUrl + "Employee/AddEmployee";

            Employee employee = new Employee();
            employee.FirstName = txtFirstName.Text;
            employee.LastName = txtLastName.Text;
            employee.DOB = txtDOB.Text;
            employee.SSN = Convert.ToInt32(txtSSN.Text);
            employee.Gender = string.IsNullOrEmpty(rdoGender.SelectedValue) ? (rdoGender.SelectedValue.Equals("M") ? "M" : "F") : "M";
            employee.Salary = Convert.ToInt32(txtSalary.Text);
            employee.Email = txtEmail.Text;

            using (WebClient client = new WebClient())
            {
                string stringToUpload = JsonConvert.SerializeObject(employee);
                client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                client.UploadString(apiUrl, "POST", stringToUpload);
            }

            Response.Redirect("/");
        }
    }
}