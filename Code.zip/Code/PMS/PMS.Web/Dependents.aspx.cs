﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using PMS.Models;
using PMS.Web.Helper;
using Newtonsoft.Json;

namespace PMS.Web
{
    public partial class Contact : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                WebClient client = new WebClient();

                List<DependentType> lstDependentTypesList = JsonConvert.DeserializeObject<List<DependentType>>(client.DownloadString(ConfigHelper.ApiUrl + "DependentType"));

                foreach(DependentType type in lstDependentTypesList)
                {
                    ddlDependentType.Items.Add(new ListItem() {
                        Text=type.DeptTypeName,
                        Value=type.DeptTypeId.ToString(),
                    });
                }

                client = new WebClient();

                List<Tuple<int, string>> lstEmployees = JsonConvert.DeserializeObject<List<Tuple<int, string>>>(client.DownloadString(ConfigHelper.ApiUrl + "Employees"));

                foreach (Tuple<int, string> type in lstEmployees)
                {
                    ddlEmployeeList.Items.Add(new ListItem()
                    {
                        Value = type.Item1.ToString(),
                        Text = type.Item2.ToString()
                    });
                }
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string apiUrl = ConfigHelper.ApiUrl + "Dependent/AddDependent";

            Dependent dependent = new Dependent();
            dependent.FirstName = txtFirstName.Text;
            dependent.LastName = txtLastName.Text;
            dependent.DOB = txtDOB.Text;
            dependent.SSN = Convert.ToInt32(txtSSN.Text);
            dependent.EmpId = Convert.ToInt32(ddlEmployeeList.SelectedItem.Value);
            dependent.DeptTypeId = Convert.ToInt32(ddlDependentType.SelectedItem.Value);


            using (WebClient client = new WebClient())
            {
                string stringToUpload = JsonConvert.SerializeObject(dependent);
                client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                client.UploadString(apiUrl, "POST", stringToUpload);
            }

            Response.Redirect("/");
        }
    }
}