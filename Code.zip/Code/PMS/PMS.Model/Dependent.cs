﻿using System;

namespace PMS.Model
{
    public class Dependent
    {
        public int EmpId { get; set; }
        public int DeptTypeId { get; set; }
        public string Prefix { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Suffix { get; set; }
        public string DOB { get; set; }
        public int SSN { get; set; }
    }

    public class DependentType
    {
        public int DeptTypeId { get; set; }
        public string DeptTypeName { get; set; }
    }
}
