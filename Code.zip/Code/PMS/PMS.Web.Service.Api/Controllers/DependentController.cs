﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMS.Model;
using PMS.Data;

namespace PMS.Web.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DependentController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // GET: api/<EmployeeController>
        [HttpGet]
        public List<DependentType> Get()
        {
            return PMSData.GetAllDependentTypes();
        }

        [HttpPost]
        [Route("AddDependent")]
        public void Post([FromBody] Dependent dependent)
        {
            if (dependent != null)
            {
                PMSData.AddNewDependent(dependent);
            }
        }

    }
}
