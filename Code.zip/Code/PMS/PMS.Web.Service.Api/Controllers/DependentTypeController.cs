﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMS.Model;
using PMS.Data;

namespace PMS.Web.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DependentTypeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // GET: api/<EmployeeController>
        [HttpGet]
        public List<DependentType> Get()
        {
            return PMSData.GetAllDependentTypes();
        }
    }
}
