﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PMS.Model;
using PMS.Data;

namespace PMS.Web.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EmployeeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        // GET: api/<EmployeeController>
        [HttpGet]
        public List<Dashboard> Get()
        {
            //return PMSData.GetAllEmployees();
            return PMSData.GenerateHomeDashboard();
        }

        [HttpPost]
        [Route("AddEmployee")]
        public void Post([FromBody] Employee employee)
        {
            if (employee != null)
            {
                PMSData.AddNewEmployee(employee);
            }
        }
    }

    [ApiController]
    [Route("[controller]")]
    public class EmployeesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public List<Tuple<int, string>> Get()
        {
            return PMSData.GetAllEmployeeNames();
        }

    }
}
