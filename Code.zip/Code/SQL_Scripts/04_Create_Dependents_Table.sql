CREATE TABLE [Dependents]
(

[DependentId] INT IDENTITY(1, 1) PRIMARY KEY,
[EmpId] INT REFERENCES [Employees]([EmpId]),
[DeptTypeId] INT REFERENCES [DependentTypes]([Id]),
[Prefix] VARCHAR(2),
[FirstName] VARCHAR(50) NOT NULL,
[MiddleName] VARCHAR(50),
[LastName] VARCHAR(50) NOT NULL,
[Suffix] VARCHAR(2),
[DOB] DATE NOT NULL,
[SSN] INT NOT NULL

);

