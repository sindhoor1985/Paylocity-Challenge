USE [PMS]
GO


IF EXISTS(SELECT 1 FROM sys.procedures WHERE Name = 'usp_GetAllEmployees')
BEGIN
    DROP PROCEDURE dbo.usp_GetAllEmployees
END
GO

--Usage

--exec [dbo].[usp_GetAllEmployees]


CREATE PROCEDURE [dbo].[usp_GetAllEmployees]

AS



SELECT [EmpId]
,LEFT(FullName + space(20), 20) + LEFT(FormattedSSN + space(20), 20) AS [Name]
FROM
(SELECT [EmpId]
      ,[FirstName] + ' ' + [LastName] AS [FullName] 
	  ,' (' + STUFF( STUFF(RIGHT('000000000' + CAST([SSN] AS VARCHAR), 9), 4, 0, '-'), 7, 0, '-') + ')' AS [FormattedSSN]
FROM [PMS].[dbo].[Employees]) AS T
ORDER BY [FullName]


GO