USE [PMS]
GO


IF EXISTS(SELECT 1 FROM sys.procedures WHERE Name = 'usp_GeneratePMSDashboard')
BEGIN
    DROP PROCEDURE dbo.usp_GeneratePMSDashboard
END
GO

--Usage

--exec [dbo].[usp_GeneratePMSDashboard] '1', '1', '', 'Frank', '', 'Doe', '', '1/1/2005', '457697758'
--exec [dbo].[usp_GeneratePMSDashboard] '1', '5', '', 'Emilee', '', 'Doe', '', '1/1/2010', '474947576'
--SELECT * FROM [dbo].[Dependents] WHERE [EmpId]='1'


CREATE PROCEDURE [dbo].[usp_GeneratePMSDashboard]


AS 

SELECT B.[EmpId],B.[FirstName],B.[LastName],B.[DOB],B.[SSN],B.[Gender],B.[Salary],B.[Email], A.[EmpBenefitsCost] AS [EmployeeBenefitsCost], A.[DepBenefitsCost] AS [DependentBenefitsCost]
FROM
(SELECT A.[EmpId], SUM([EmpBenefitsCost]) [EmpBenefitsCost], SUM([DepBenefitsCost]) [DepBenefitsCost] 
FROM
(SELECT E.[EmpId],E.[FirstName],E.[LastName],E.[DOB],E.[SSN],E.[Gender],E.[Salary],E.[Email], CASE WHEN [FIRSTNAME] LIKE 'A%' THEN 900 ELSE 1000 END [EmpBenefitsCost]
FROM [PMS].[dbo].[Employees] E) A
INNER JOIN
(SELECT E.[EmpId],E.[FirstName],E.[LastName],E.[DOB],E.[SSN],E.[Gender],E.[Salary],E.[Email], CASE WHEN D.[FIRSTNAME] IS NULL THEN 0 ELSE CASE WHEN D.[FIRSTNAME] LIKE 'A%' THEN 450 ELSE 500 END END [DepBenefitsCost] 
FROM [PMS].[dbo].[Employees] E LEFT OUTER JOIN [PMS].[dbo].[Dependents] D ON E.EmpId = D.EmpId) B
ON A.[EmpId]=B.[EmpId]
GROUP BY A.[EmpId]) A
INNER JOIN [PMS].[dbo].[Employees] B
ON A.[EmpId]=B.[EmpId]

GO