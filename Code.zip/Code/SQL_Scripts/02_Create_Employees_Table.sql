
--DROP TABLE [Dependents]
--DROP TABLE [Employees]

CREATE TABLE [Employees]
(

[EmpId] INT IDENTITY(1, 1) PRIMARY KEY,
[Prefix] VARCHAR(2),
[FirstName] VARCHAR(50) NOT NULL,
[MiddleName] VARCHAR(50),
[LastName] VARCHAR(50) NOT NULL,
[Suffix] VARCHAR(2),
[DOB] DATE NOT NULL,
[StateId] VARCHAR(20),
[PassportNumber] VARCHAR(20),
[Gender] CHAR(1) NOT NULL, -- M - Male, F - Female, X - Transgender
[SSN] INT NOT NULL UNIQUE,
[Salary] INT NOT NULL,
[Position] VARCHAR(50),
[BusinessTitle] VARCHAR(50),
[JobProfile] VARCHAR(50),
[TeammateType] CHAR(1), -- P - Permanent Employees/FTEs, T - Temporary Employees/Contractors
[Location] VARCHAR(50),
[HireDate] DATE NOT NULL,
[PhoneNumber] VARCHAR(20),
[Email] VARCHAR(50)

);

