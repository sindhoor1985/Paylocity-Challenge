--DROP TABLE [DependentTypes]


CREATE TABLE [DependentTypes]
(

[Id] INT IDENTITY(1, 1) PRIMARY KEY,
[Type] VARCHAR(50),

);

INSERT INTO [DependentTypes]
SELECT 'Spouse' AS [Type]

INSERT INTO [DependentTypes]
SELECT 'Child'

INSERT INTO [DependentTypes]
SELECT 'Qualifying Child'

INSERT INTO [DependentTypes]
SELECT 'Dependent Parent'

INSERT INTO [DependentTypes]
SELECT 'Domestic Partner'

INSERT INTO [DependentTypes]
SELECT 'Domestic Partner Child'

--SELECT * FROM [DependentTypes]