USE [PMS]
GO


IF EXISTS(SELECT 1 FROM sys.procedures WHERE Name = 'usp_AddNewEmployee')
BEGIN
    DROP PROCEDURE dbo.usp_AddNewEmployee
END
GO

--Usage

--exec [dbo].[usp_AddNewEmployee] '', 'John', '', 'Doe', '', '1/1/1980', 'VA-123', 'GHSX7F-8745', 'M', '457484758', '120000', 'Software Engineer II', 'Assistant Vice President', 'AVP - Application Developer', 'P', '', '01/01/2020', '457-458-4545', 'John.Doe@MyCompany.com'
--exec [dbo].[usp_AddNewEmployee] '', 'Jane', '', 'Doe', '', '1/1/1980', 'NC-123', 'EUSF3S-7458', 'F', '474741576', '150000', 'Manager', 'Vice President', 'VP - Application Development Manager', 'T', '', '01/01/2010', '476-958-3579', 'Jane.Doe@MyCompany.com'
--SELECT * FROM [dbo].[Employees]


CREATE PROCEDURE [dbo].[usp_AddNewEmployee]
(

@Prefix VARCHAR(2) = NULL,
@FirstName VARCHAR(50),
@MiddleName VARCHAR(50) = NULL,
@LastName VARCHAR(50),
@Suffix VARCHAR(2) = NULL,
@DOB DATE,
@StateId VARCHAR(20) = NULL,
@PassportNumber VARCHAR(20) = NULL,
@Gender CHAR(1), -- M - Male, F - Female, X - Transgender
@SSN INT,
@Salary INT,
@Position VARCHAR(50) = NULL,
@BusinessTitle VARCHAR(50) = NULL,
@JobProfile VARCHAR(50) = NULL,
@TeammateType CHAR(1) = NULL, -- P - Permanent Employees/FTEs, T - Temporary Employees/Contractors
@Location VARCHAR(50) = NULL,
@HireDate DATE = NULL,
@PhoneNumber VARCHAR(20) = NULL,
@Email VARCHAR(50) = NULL
)

AS

IF @HireDate IS NULL
SET @HireDate = GETDATE()

INSERT INTO [dbo].[Employees] (
[Prefix],
[FirstName],
[MiddleName],
[LastName],
[Suffix],
[DOB],
[StateId],
[PassportNumber],
[Gender],
[SSN],
[Salary],
[Position],
[BusinessTitle],
[JobProfile],
[TeammateType],
[Location],
[HireDate],
[PhoneNumber],
[Email]
) 
SELECT 
@Prefix,
@FirstName,
@MiddleName,
@LastName,
@Suffix,
@DOB,
@StateId,
@PassportNumber,
@Gender,
@SSN,
@Salary,
@Position,
@BusinessTitle,
@JobProfile,
@TeammateType,
@Location,
@HireDate,
@PhoneNumber,
@Email

GO