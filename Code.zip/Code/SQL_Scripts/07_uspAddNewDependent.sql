USE [PMS]
GO


IF EXISTS(SELECT 1 FROM sys.procedures WHERE Name = 'usp_AddNewDependent')
BEGIN
    DROP PROCEDURE dbo.usp_AddNewDependent
END
GO

--Usage

--exec [dbo].[usp_AddNewDependent] '1', '1', '', 'Frank', '', 'Doe', '', '1/1/2005', '457697758'
--exec [dbo].[usp_AddNewDependent] '1', '5', '', 'Emilee', '', 'Doe', '', '1/1/2010', '474947576'
--SELECT * FROM [dbo].[Dependents] WHERE [EmpId]='1'


CREATE PROCEDURE [dbo].[usp_AddNewDependent]
(

@EmpId INT,
@DeptTypeId INT,
@Prefix VARCHAR(2) = NULL,
@FirstName VARCHAR(50),
@MiddleName VARCHAR(50) = NULL,
@LastName VARCHAR(50),
@Suffix VARCHAR(2) = NULL,
@DOB DATE,
@SSN INT
)

AS

INSERT INTO [dbo].[Dependents] (
	   [EmpId]
      ,[DeptTypeId]
      ,[Prefix]
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Suffix]
      ,[DOB]
      ,[SSN]
) 
SELECT @EmpId
      ,@DeptTypeId
      ,@Prefix
      ,@FirstName
      ,@MiddleName
      ,@LastName
      ,@Suffix
      ,@DOB
      ,@SSN

GO