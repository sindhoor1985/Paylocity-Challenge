USE [PMS]
GO


IF EXISTS(SELECT 1 FROM sys.procedures WHERE Name = 'usp_FindEmployee')
BEGIN
    DROP PROCEDURE dbo.usp_FindEmployee
END
GO

--Usage

--exec [dbo].[usp_FindEmployee] '1'
--exec [dbo].[usp_FindEmployee] '2'

--SELECT * FROM [dbo].[Employees]


CREATE PROCEDURE [dbo].[usp_FindEmployee]
(
@EmpId INT
)

AS

SELECT [EmpId]
      ,[Prefix]
      ,[FirstName]
      ,[MiddleName]
      ,[LastName]
      ,[Suffix]
      ,[DOB]
      ,[StateId]
      ,[PassportNumber]
      ,[Gender]
      ,[SSN]
      ,[Salary]
      ,[Position]
      ,[BusinessTitle]
      ,[JobProfile]
      ,[TeammateType]
      ,[Location]
      ,[HireDate]
      ,[PhoneNumber]
      ,[Email]
  FROM [PMS].[dbo].[Employees]
  WHERE [EmpId] = @EmpId

GO